<?php 
include 'dbh.php';

if (isset($_POST['upload'])) {
  for ($x=0; $x < count($_FILES['upload']['name']); $x++) { 
    $name = $_FILES['upload']['name'][$x];
    $size = $_FILES['upload']['size'][$x];
    $type = $_FILES['upload']['type'][$x];
    $tmp_name = $_FILES['upload']['tmp_name'][$x];

    $file_name = date('Ymd-His', time()).mt_rand().'-'.$name;

    $dir = 'uploads/';

    $extension = pathinfo($name, PATHINFO_EXTENSION);
    $file_location =  $dir.$file_name;
    if (move_uploaded_file($tmp_name, $file_location)) {
      echo "file uploaded succesfully <br>";
      echo $extension;

      $sql = "INSERT INTO files (name, extension, location ,size)
      VALUES ('$name', '$extension', '$file_location', '$size')";

      if (mysqli_query($conn, $sql)) {
    
         echo '<script>alert("New record created successfully");</script>';
         echo '<script>window.location.href = "index.php";</script>';
        
      } else {
          echo "Error: " . $sql . "<br>" . mysqli_error($conn);
      }

    }
  }
}
 ?>

<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>
       <nav>
    <div class="nav-wrapper container">

      <form>
        <div class="input-field">
          <input id="search" type="search" required>
          <label class="label-icon" for="search"><i class="material-icons">search</i></label>
          <i class="material-icons">close</i>
        </div>
      </form>
    </div>
  </nav>



<br><br>

         <div class="container">
           <div class="row">
            <div class="col m5 s12 card-panel hoverable">
              <br><br>
               <h5>upload your files</h5>
              <br>
              <form  method="post" action="index.php" enctype="multipart/form-data">
              <div class="file-field input-field">
                  <div class="btn">
                    <span>File</span>
                    <input type="file" name="upload[]" multiple="multiple">
                  </div>
                  <div class="file-path-wrapper">
                    <input class="file-path validate" type="text" placeholder="Upload one or more files">
                  </div>
                  <br>
                   <button class="btn waves-effect waves-light" type="submit" name="upload">Submit
                    <i class="material-icons right">upload</i>
                  </button>
                </form>
                  <br><br><br><br>
                </div>
            </div>




            <div class="col m6 s12 card-panel" style="margin-left:10px;" >
              <h5>click to download</h5>

              <?php 

$sql = "SELECT * FROM files ORDER BY id DESC";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
    


        echo '<a href="'.$row['location'].'" style="text-decoration:none;color:black;" download><table class="card-panel hoverable">
                <tr style="float:left;"><td><img src="img/download.jpg" style="width:60px;height:60px;"></td>
                <td ><strong>name : </strong>'.$row["name"].' <br>
                  <strong>size : </strong>'.$row["size"].' bytes <br>
                  <strong>time : </strong>'.date($row["time"]).'<br>
                </td>
              
                </tr>
              </table></a>';
    }
} else {
    echo "0 results";
}

 ?>


              





            </div>





            </div>

         </div>


<br><br><br><br>
 <footer class="page-footer">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Footer Content</h5>
                <p class="grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 1</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 2</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 3</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Link 4</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2014 Copyright Text
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
        </footer>


      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="js/materialize.min.js"></script>
     
    </body>
  </html>

