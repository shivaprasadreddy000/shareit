<?php 
$conn = mysqli_connect("localhost", 'root' , '' ,'share');

if (!$conn) {
	die("error in connecting database".mysqli_connect_error());
}

 ?>